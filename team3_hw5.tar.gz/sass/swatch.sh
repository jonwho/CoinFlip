#!/bin/bash
sass --watch style.scss:../style/style.css
