To auto map scss to sass, simply run:

./swatch.sh

And everytime you save on the scss file it will automatically be mapped to the /style/style.css file.
